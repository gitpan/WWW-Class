package Webby::Server;

sub null { }

1;
